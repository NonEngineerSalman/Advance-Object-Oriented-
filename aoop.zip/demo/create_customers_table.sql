-- Drop tables if they exist (in correct order due to foreign keys)
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS purchases;

-- Create customers table with proper foreign key
CREATE TABLE customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id VARCHAR(250),
    movie_title VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    table_no VARCHAR(50),
    time VARCHAR(50),
    date VARCHAR(50),
    total_payment VARCHAR(50),
    ticket_number VARCHAR(100) UNIQUE,
    CONSTRAINT fk_customers_users
    FOREIGN KEY (user_id) REFERENCES users(username)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB; 