-- First ensure the users table has the correct structure
ALTER TABLE users
MODIFY username VARCHAR(250) NOT NULL,
ADD PRIMARY KEY (username) IF NOT EXISTS;

-- Now add the user_id column to customers table with correct foreign key
ALTER TABLE customers
ADD COLUMN user_id VARCHAR(250),
ADD CONSTRAINT fk_customers_users
FOREIGN KEY (user_id) REFERENCES users(username)
ON DELETE CASCADE
ON UPDATE CASCADE;

-- Update purchases table with username reference
ALTER TABLE purchases
ADD COLUMN username VARCHAR(250),
ADD CONSTRAINT fk_purchases_users
FOREIGN KEY (username) REFERENCES users(username)
ON DELETE CASCADE
ON UPDATE CASCADE;

-- Add name and email columns to users table
ALTER TABLE users 
ADD COLUMN name VARCHAR(250) AFTER password,
ADD COLUMN email VARCHAR(250) AFTER name,
ADD UNIQUE INDEX idx_users_email (email);

-- Add email and name columns to users table
ALTER TABLE users 
ADD COLUMN email VARCHAR(255) UNIQUE,
ADD COLUMN name VARCHAR(255);

-- Update existing admin user
UPDATE users SET email = 'admin@moviebook.com', name = 'Administrator' WHERE username = 'admin'; 