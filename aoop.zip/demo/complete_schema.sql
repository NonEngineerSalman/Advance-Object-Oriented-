-- Drop existing tables in correct order
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS purchases;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
    username VARCHAR(250) PRIMARY KEY,
    password VARCHAR(250) NOT NULL,
    role INT NOT NULL DEFAULT 1, -- 0 for admin, 1 for customer
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create movies table
CREATE TABLE movies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    duration VARCHAR(50),
    poster_path VARCHAR(500),
    date VARCHAR(50),
    status VARCHAR(50), -- 'Now Showing' or 'Coming Soon'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create purchases table
CREATE TABLE purchases (
    id INT PRIMARY KEY AUTO_INCREMENT,
    movie_id INT NOT NULL,
    username VARCHAR(250) NOT NULL,
    normal_qty INT DEFAULT 0,
    special_qty INT DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Create customers table (for ticket details)
CREATE TABLE customers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id VARCHAR(250) NOT NULL,
    movie_title VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    table_no VARCHAR(50),
    time VARCHAR(50),
    date VARCHAR(50),
    total_payment DECIMAL(10,2) NOT NULL,
    ticket_number VARCHAR(100) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(username) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Insert default admin user
INSERT INTO users (username, password, role) VALUES ('admin', 'admin', 0);

-- Create indexes for better performance
CREATE INDEX idx_movies_status ON movies(status);
CREATE INDEX idx_customers_user_id ON customers(user_id);
CREATE INDEX idx_purchases_username ON purchases(username);
CREATE INDEX idx_customers_ticket_number ON customers(ticket_number); 